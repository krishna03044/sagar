
(function() {
    function call (){
        alert("yes")
    }
  
    window.addEventListener("scroll", call);
  
  })();
















